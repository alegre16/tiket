<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "tickets";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$nombre = $_POST['nombre'];
$gmail = $_POST['gmail'];

$sql = "INSERT INTO ticket (nombre, gmail) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $nombre, $gmail);

if ($stmt->execute()) {
    echo "Ticket registrado con éxito.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
