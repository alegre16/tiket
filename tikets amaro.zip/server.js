import express from "express";
import mysql from "mysql2";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Configuración de MySQL
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "tickets"
});

db.connect(err => {
    if (err) {
        console.error("Error conectando a la base de datos:", err);
    } else {
        console.log("Conectado a MySQL");
    }
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Ruta para manejar el envío del ticket
app.post("/ticket", (req, res) => {
    const { nombre, gmail } = req.body;
    const sql = "INSERT INTO ticket (nombre, gmail) VALUES (?, ?)";
    db.query(sql, [nombre, gmail], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error al registrar el ticket");
        } else {
            res.send("Ticket registrado con éxito");
        }
    });
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
